import torch
import torch.nn as nn
import math

class GPT2Config:
    def __init__(self, vocab_size=50257, n_positions=1024, n_embd=768, n_layer=12, n_head=12, 
                 activation_function="gelu", resid_pdrop=0.1, embd_pdrop=0.1, attn_pdrop=0.1):
        self.vocab_size = vocab_size
        self.n_positions = n_positions
        self.n_embd = n_embd
        self.n_layer = n_layer
        self.n_head = n_head
        self.activation_function = activation_function
        self.resid_pdrop = resid_pdrop
        self.embd_pdrop = embd_pdrop
        self.attn_pdrop = attn_pdrop

class GPT2Attention(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.n_head = config.n_head
        self.n_embd = config.n_embd
        self.split_size = config.n_embd
        self.scale = math.sqrt(self.split_size // self.n_head)
        
        self.c_attn = nn.Linear(config.n_embd, 3 * config.n_embd)
        self.c_proj = nn.Linear(config.n_embd, config.n_embd)
        self.attn_dropout = nn.Dropout(config.attn_pdrop)
        self.resid_dropout = nn.Dropout(config.resid_pdrop)

    def _attn(self, q, k, v, attention_mask=None):
        w = torch.matmul(q, k.transpose(-1, -2))
        w = w / self.scale
        
        if attention_mask is not None:
            w = w + attention_mask

        w = nn.Softmax(dim=-1)(w)
        w = self.attn_dropout(w)
        
        output = torch.matmul(w, v)
        return output

    def merge_heads(self, x):
        x = x.permute(0, 2, 1, 3).contiguous()
        new_x_shape = x.size()[:-2] + (x.size(-2) * x.size(-1),)
        return x.view(*new_x_shape)

    def split_heads(self, x):
        new_x_shape = x.size()[:-1] + (self.n_head, x.size(-1) // self.n_head)
        x = x.view(*new_x_shape)
        return x.permute(0, 2, 1, 3)
    
    def forward(self, x, attention_mask=None):
        x = self.c_attn(x)
        query, key, value = x.split(self.split_size, dim=2)
        query = self.split_heads(query)
        key = self.split_heads(key)
        value = self.split_heads(value)

        a = self._attn(query, key, value, attention_mask)
        a = self.merge_heads(a)
        a = self.c_proj(a)
        a = self.resid_dropout(a)
        
        return a

class GPT2MLP(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.c_fc = nn.Linear(config.n_embd, 2 * config.n_embd)
        self.c_proj = nn.Linear(2 * config.n_embd, config.n_embd)
        self.act = nn.GELU() if config.activation_function == "gelu" else nn.ReLU()
        self.dropout = nn.Dropout(config.resid_pdrop)

    def forward(self, x):
        h = self.act(self.c_fc(x))
        h2 = self.c_proj(h)
        return self.dropout(h2)

class GPT2Block(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.ln_1 = nn.LayerNorm(config.n_embd)
        self.attn = GPT2Attention(config)
        self.ln_2 = nn.LayerNorm(config.n_embd)
        self.mlp = GPT2MLP(config)

    def forward(self, x, attention_mask=None):
        a = self.attn(self.ln_1(x), attention_mask=attention_mask)
        x = x + a
        m = self.mlp(self.ln_2(x))
        x = x + m
        return x

class GPT2Model(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.wte = nn.Embedding(config.vocab_size, config.n_embd)
        self.wpe = nn.Embedding(config.n_positions, config.n_embd)
        self.drop = nn.Dropout(config.embd_pdrop)
        self.h = nn.ModuleList([GPT2Block(config) for _ in range(config.n_layer)])
        self.ln_f = nn.LayerNorm(config.n_embd)

    def forward(self, input_ids, position_ids=None, attention_mask=None):
        if position_ids is None:
            position_ids = torch.arange(0, input_ids.size(-1), dtype=torch.long, device=input_ids.device)
            position_ids = position_ids.unsqueeze(0).expand_as(input_ids)

        input_shape = input_ids.size()
        input_ids = input_ids.view(-1, input_shape[-1])
        position_ids = position_ids.view(-1, input_shape[-1])

        inputs_embeds = self.wte(input_ids)
        position_embeds = self.wpe(position_ids)
        hidden_states = inputs_embeds + position_embeds
        hidden_states = self.drop(hidden_states)

        if attention_mask is not None:
            attention_mask = attention_mask.unsqueeze(1).unsqueeze(2)
            attention_mask = attention_mask.to(dtype=next(self.parameters()).dtype)
            attention_mask = (1.0 - attention_mask) * -10000.0

        for block in self.h:
            hidden_states = block(hidden_states, attention_mask)

        hidden_states = self.ln_f(hidden_states)
        return hidden_states

class GPT2LMHeadModel(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.transformer = GPT2Model(config)
        self.lm_head = nn.Linear(config.n_embd, config.vocab_size, bias=False)

    def forward(self, input_ids, position_ids=None, attention_mask=None):
        hidden_states = self.transformer(input_ids, position_ids, attention_mask)
        lm_logits = self.lm_head(hidden_states)
        return lm_logits

def gpt2_tiny(vocab_size, seq_length):
    config = GPT2Config(vocab_size, n_embd=64, n_layer=4, n_head=2, n_positions=seq_length)
    return GPT2LMHeadModel(config)

def gpt2_small(vocab_size, seq_length):
    config = GPT2Config(vocab_size, n_embd=256, n_layer=8, n_head=4, n_positions=seq_length)
    return GPT2LMHeadModel(config)

def gpt2_medium(vocab_size, seq_length):
    config = GPT2Config(vocab_size, n_embd=1024, n_layer=24, n_head=16, n_positions=seq_length)
    return GPT2LMHeadModel(config)

def gpt2_large(vocab_size, seq_length):
    config = GPT2Config(vocab_size, n_embd=1280, n_layer=36, n_head=20, n_positions=seq_length)
    return GPT2LMHeadModel(config)

def gpt2_xl(vocab_size, seq_length):
    config = GPT2Config(vocab_size, n_embd=1600, n_layer=48, n_head=25, n_positions=seq_length)
    return GPT2LMHeadModel(config)
